export function Header(){

    return(
        <section>
            <div className="Header">Header</div>

        </section>

    );

}

