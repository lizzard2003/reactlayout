//import"./Foter.css"
export function Footer(){

    return(
        <section>
            <br/>

            <div className="boxfooter">footer</div>

        </section>

    );

}