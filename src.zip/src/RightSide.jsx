export function Right(){

    return(
        <section>
            <div className="box-right-side">Right side</div>

        </section>

    );

}