
export function Leftside(){

    return(
        <section>

            <div className="boxleft">Leftside</div>

        </section>

    );

}